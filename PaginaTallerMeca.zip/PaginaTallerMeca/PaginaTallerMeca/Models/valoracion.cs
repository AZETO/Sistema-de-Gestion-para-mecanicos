﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;



namespace PaginaTallerMeca.Models
{
    public class valoracion
    {
        public int ID_valo { get; set; }
        public string tipo_servicio { get; set; }
        public string comentario { get; set; }
        public int nota { get; set; }

    }

    public class valoracionContext : DbContext
    {
        public DbSet<valoracion> valoracion { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }




}
