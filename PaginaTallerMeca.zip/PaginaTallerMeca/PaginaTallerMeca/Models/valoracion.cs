﻿namespace PaginaTallerMeca.Models
{
    public class valoracion
    {
        public int ID_valo { get; set; }
        public string tipo_servicio { get; set; }
        public string comentario { get; set; }
        public int nota { get; set; }

    }
}
