﻿namespace PaginaTallerMeca.Models
{
    public class usuario_mecanico
    {
        public int ID_mecanico { get; set; }
        public string nombre { get; set; }
        public string password { get; set; }
        public string email { get; set; }





    }
}
