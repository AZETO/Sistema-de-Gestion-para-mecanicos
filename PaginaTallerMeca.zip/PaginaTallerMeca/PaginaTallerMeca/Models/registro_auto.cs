﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;



namespace PaginaTallerMeca.Models
{
    public class registro_auto
    {
        public int  ID { get; set; }
        public int ID_dueño { get; set; }
        public string marca { get; set; }
        public string modelo { get; set; }
        public string año { get; set; }
        public string tipo_motor{ get; set; }



    }
    public class registro_autoContext : DbContext
    {
        public DbSet<registro_auto> registro_auto { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }


}
