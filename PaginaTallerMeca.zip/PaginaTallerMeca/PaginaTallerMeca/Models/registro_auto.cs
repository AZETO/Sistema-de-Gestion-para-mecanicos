﻿namespace PaginaTallerMeca.Models
{
    public class registro_auto
    {
        public int  ID { get; set; }
        public int ID_dueño { get; set; }
        public string marca { get; set; }
        public string modelo { get; set; }
        public string año { get; set; }
        public string tipo_motor{ get; set; }



    }
}
