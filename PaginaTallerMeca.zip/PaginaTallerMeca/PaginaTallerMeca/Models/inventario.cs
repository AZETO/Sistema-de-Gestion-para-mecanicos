﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace PaginaTallerMeca.Models
{
    public class inventario
    {
        public int ID { get; set; }
        public string nombre_producto { get; set; }
        public string imagen { get; set; }
        public string descripcion { get; set; }
        public int stock { get; set; }
        public int precio { get; set; }



    }

    public class inventarioContext : DbContext
    {
        public DbSet<inventario> inventario { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }



}
