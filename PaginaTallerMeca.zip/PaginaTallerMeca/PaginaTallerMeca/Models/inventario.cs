﻿namespace PaginaTallerMeca.Models
{
    public class inventario
    {
        public int ID { get; set; }
        public string nombre_producto { get; set; }
        public string imagen { get; set; }
        public string descripcion { get; set; }
        public int stock { get; set; }
        public int precio { get; set; }








    }
}
