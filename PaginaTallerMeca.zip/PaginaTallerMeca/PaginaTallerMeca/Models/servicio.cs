﻿namespace PaginaTallerMeca.Models
{
    public class servicio
    {
        public int id_servicio { get; set; }
        public string nombre { get; set; }
        public string descripcion { get; set; }
        public DateTime fecha { get; set; }

    }
}
