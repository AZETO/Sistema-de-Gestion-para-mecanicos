﻿namespace PaginaTallerMeca.Models
{
    public class perfil_taller
    {
        public int ID_perfil{ get; set; }

        public string nombre_mecanico { get; set; }
        public string nombre_taller { get; set; }
        public string direccion_taller { get; set; }
        public string venta_producto { get; set; }
        public string servicio { get; set; }
        public string telefono_taller { get; set; }





    }
}
