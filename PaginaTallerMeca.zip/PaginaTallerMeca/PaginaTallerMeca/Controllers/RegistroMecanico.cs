﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class RegistroMecanico : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
