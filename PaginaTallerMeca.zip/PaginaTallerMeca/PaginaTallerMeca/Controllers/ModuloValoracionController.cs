﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class ModuloValoracionController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
