﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class CatalogosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
