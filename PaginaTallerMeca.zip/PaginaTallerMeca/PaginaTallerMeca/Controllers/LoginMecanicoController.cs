﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class LoginMecanicoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
