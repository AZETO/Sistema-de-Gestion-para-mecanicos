﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class ComprobanteController : Controller
    {
        public IActionResult Index()
        {

            return View();
        }
    }
}
