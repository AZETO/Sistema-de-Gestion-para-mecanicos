﻿using Microsoft.AspNetCore.Mvc;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Controllers
{
    public class RegistroMecanico : Controller
    {
        public IActionResult Index()
        {
            var db = new usuario_mecanicoContext();
            var registro = db.usuario_mecanico.ToList();
            ViewBag.registros = registro;


            return View();
        }
    }
}
