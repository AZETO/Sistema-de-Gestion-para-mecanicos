﻿using Microsoft.AspNetCore.Mvc;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Controllers
{
    
    public class RegistroController : Controller
    {
        public IActionResult Index()
        {
            //se encuentra en models: usuario_cliente en la linia 29 "usuario_clienteContext"
            var db = new usuario_clienteContext();

            //se encuentra en models: usuario_cliente en la linia 31 "usuario_cliente" que seria una tabla de la base de datos


            var registro = db.usuario_cliente.ToList();
            ViewBag.registros = registro;
            return View();
        }
    }
}
