﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;




namespace PaginaTallerMeca.Models
{
    public class perfil_taller
    {
        public int ID_perfil{ get; set; }

        public string nombre_mecanico { get; set; }
        public string nombre_taller { get; set; }
        public string direccion_taller { get; set; }
        public string venta_producto { get; set; }
        public string servicio { get; set; }
        public string telefono_taller { get; set; }

    }
    public class perfil_tallerContext : DbContext
    {
        public DbSet<perfil_taller> perfil_taller { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }


}
