﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;


namespace PaginaTallerMeca.Models
{
    public class usuario_cliente
    {
        int id_cliente;
        String nombre;
        String usuario;
        String rut;
        String telefono;
        String direccion;
        String correo;
        String password;
        DateTime fecha;

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public int Id_cliente { get => id_cliente; set => id_cliente=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Nombre { get => nombre; set => nombre=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Usuario { get => usuario; set => usuario=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Rut { get => rut; set => rut=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Telefono { get => telefono; set => telefono=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Direccion { get => direccion; set => direccion=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Correo { get => correo; set => correo=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Password { get => password; set => password=value; }


        public DateTime Fecha { get => fecha; set => fecha=value; }
    }


    public class usuario_clienteContext : DbContext
    {
        public DbSet<usuario_cliente> usuario_cliente { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=localhost;database=db_sistema_mecanico;user=root;password=12345");
        }
    }







}
