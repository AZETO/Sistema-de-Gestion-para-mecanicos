﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace PaginaTallerMeca.Models
{
    public class boleta_canje
    {
        public int id { get; set; }
        public string nombre_cliente { get; set; }
        public string correo_cliente { get; set; }
        public string rut_cliente { get; set; }
        public string nombre_taller { get; set; }
        public string direccion_taller { get; set; }
        public string correo_mecanico { get; set; }
        public string servicio_venta { get; set; }
        public int precio { get; set; }
        public DateTime  fecha { get; set; }


    }

    public class boleta_canjeContext : DbContext
    {
        public DbSet<boleta_canje> boleta_canje { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }


}
