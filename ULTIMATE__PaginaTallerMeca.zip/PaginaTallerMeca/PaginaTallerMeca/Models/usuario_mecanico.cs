﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;



namespace PaginaTallerMeca.Models
{
    public class usuario_mecanico

    {
        int ID_mecanico;
        String nombre;
        String usuario;
        String email;
        String password;
        String nombre_taller;
        String direccion_taller;
        String venta_producto;
        String telefono_taller;

        public usuario_mecanico()
        {
        }
        
        public int ID_mecanico1 { get => ID_mecanico; set => ID_mecanico=value; }
        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Nombre { get => nombre; set => nombre=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Usuario { get => usuario; set => usuario=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Email { get => email; set => email=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Password { get => password; set => password=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Nombre_taller { get => nombre_taller; set => nombre_taller=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Direccion_taller { get => direccion_taller; set => direccion_taller=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Venta_producto { get => venta_producto; set => venta_producto=value; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string Telefono_taller { get => telefono_taller; set => telefono_taller=value; }

        public class usuario_mecanicoContext : DbContext
        {
            public DbSet<usuario_mecanico> usuario_mecanico { get; set; }

            protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
            {
                optionBuilder.UseMySQL("server=localhost;database=db_sistema_mecanico;user=root;password=12345");
            }
        }


    }
}
