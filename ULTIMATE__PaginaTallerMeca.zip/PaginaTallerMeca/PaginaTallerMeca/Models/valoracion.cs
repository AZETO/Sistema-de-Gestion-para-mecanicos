﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace PaginaTallerMeca.Models
{
    public class valoracion
    {
        public int ID_valo { get; set; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]
        public string tipo_servicio { get; set; }


        public string comentario { get; set; }


         
        public int nota { get; set; }

    }

    public class valoracionContext : DbContext
    {
        public DbSet<valoracion> valoracion { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }




}
