﻿using MySql.Data.MySqlClient;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Models
{
    internal class ControlInventario
    {
        public List<object> consulta(String dato)
        {
            MySqlDataReader reader;
            List<object> lista = new List<object>();
            string sql;

            if (dato == null)
            {
                sql = "SELECT ID, nombre_producto, descripcion, precio FROM inventario ORDER BY nombre ASC";
            }
            else
            {
                sql = "SELECT ID, nombre_producto, descripcion, precio FROM inventario WHERE id LIKE '%" + dato + "%' OR nombre LIKE '%" + dato + "%' OR descripcion LIKE '%" + dato + "%' OR precio LIKE '%" + dato + "%' ORDER BY nombre ASC";
            }
            try
            {
                MySqlConnection conexionDB = Conexion.Connexion();
                conexionDB.Open();
                MySqlCommand comando = new MySqlCommand(sql, conexionDB);
                reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    inventario _producto = new inventario();
                    _producto.ProductosId = int.Parse(reader.GetString(0));
                    //_producto.Codigo = reader[1].ToString();
                    _producto.Productos_Nombre = reader[1].ToString();
                    _producto.Producto_Descripcion = reader[2].ToString();
                    _producto.Productos_Precio = int.Parse(reader.GetString(3));
                    //_producto.Cantidad = int.Parse(reader.GetString(5));

                    lista.Add(_producto);

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            return lista;
        }
    }
}


