﻿using MySql.Data.MySqlClient;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Models
{
    internal class ControlInfo
    {
        public List<object> consulta(String dato)
        {
            MySqlDataReader reader;
            List<object> lista = new List<object>();
            string sql;

            if (dato == null)
            {
                sql = "SELECT ID_mecanico, nombre, email, nombre_taller, direccion_taller, venta_producto, telefono_taller FROM usuario_mecanico ORDER BY nombre ASC";
            }
            else
            {
                sql = "SELECT ID_mecanico, nombre, email, nombre_taller, direccion_taller, venta_producto, telefono_taller FROM usuario_mecanico WHERE nombre LIKE '%" + dato + "%' OR email LIKE '%" + dato + "%' OR nombre_taller LIKE '%" + dato + "%' OR direccion_taller LIKE '%" + dato + "%' OR venta_producto LIKE '%" + dato + "%' OR telefono_taller ORDER BY nombre ASC";
            }
            try
            {
                MySqlConnection conexionDB = Conexion.Connexion();
                conexionDB.Open();
                MySqlCommand comando = new MySqlCommand(sql, conexionDB);
                reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    usuario_mecanico _perfil = new usuario_mecanico();
                    _perfil.ID_mecanico1 = int.Parse(reader.GetString(0));
                    //_producto.Codigo = reader[1].ToString();
                    _perfil.Nombre = reader[1].ToString();
                    _perfil.Email = reader[2].ToString();
                    _perfil.Nombre_taller = reader[3].ToString();
                    _perfil.Direccion_taller = reader[4].ToString();
                    _perfil.Venta_producto = reader[5].ToString();
                    _perfil.Telefono_taller = reader[6].ToString();
                    
                    //_producto.Cantidad = int.Parse(reader.GetString(5));

                    lista.Add(_perfil);

                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            return lista;
        }
    }
}


