﻿using MySql.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;


namespace PaginaTallerMeca.Models
{
    public class servicio
    {
        public int id_servicio { get; set; }

        [Required(ErrorMessage = "Completar este campo es obligatorio")]

        public string nombre { get; set; }
        [Required(ErrorMessage = "Completar este campo es obligatorio")]

        public string descripcion { get; set; }

        [DisplayFormat(DataFormatString = "{0:d}")]
        public DateTime fecha { get; set; }

    }

    public class servicioContext : DbContext
    {
        public DbSet<servicio> servicio { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=3306;database=db_sistema_mecanico;user=root;password=12345");
        }
    }


}
