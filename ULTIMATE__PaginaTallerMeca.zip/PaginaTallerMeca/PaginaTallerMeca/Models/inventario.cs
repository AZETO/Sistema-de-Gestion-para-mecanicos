﻿using Microsoft.EntityFrameworkCore;

namespace PaginaTallerMeca.Models
{



    public class inventario
    {
        int id;
        String nombre;
        String descripcion;
        int precio;


        public inventario()
        {
        }

        public inventario(int id, string nombre, string descripcion, int precio)
        {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.precio = precio;

        }

        public int ProductosId { get => id; set => id = value; }
        public string Productos_Nombre { get => nombre; set => nombre = value; }
        public string Producto_Descripcion { get => descripcion; set => descripcion = value; }
        public int Productos_Precio { get => precio; set => precio = value; }

    }
    public class registro_autoContext : DbContext
    {
        public DbSet<registro_auto> registro_auto { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseMySQL("server=localhost;database=db_sistema_mecanico;user=root;password=12345");
        }
    }


}

