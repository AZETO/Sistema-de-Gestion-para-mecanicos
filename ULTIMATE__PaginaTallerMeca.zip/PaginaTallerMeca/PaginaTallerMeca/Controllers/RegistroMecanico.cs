﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Controllers
{
    public class RegistroMecanico : Controller
    {
        public IActionResult AgregarM()
        {
            return View();
        }


        public ActionResult AgregarPOST2(string nombre, string usuario, string email, string password, string nombre_taller, string direccion_taller, string venta_producto, string telefono_taller)
        {
            try
            {
                string cadenaConexion = "server=localhost;database=db_sistema_mecanico;user=root;password=12345";

                MySqlConnection conexionDB = Conexion.Connexion();
                string sentencia = String.Format("INSERT INTO usuario_mecanico (nombre, usuario, email, password, nombre_taller, direccion_taller, venta_producto, telefono_taller) VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')", nombre, usuario, email, password, nombre_taller, direccion_taller, venta_producto, telefono_taller);

                MySqlCommand com = new MySqlCommand(sentencia, conexionDB);

                conexionDB.Open();
                int cantidadFilasAfectadas = com.ExecuteNonQuery();
                conexionDB.Close();

                if (cantidadFilasAfectadas != 1)
                    throw new ApplicationException("No se agrego el usuario.");


                TempData["MSG"] = "Se agrego con exito: " + String.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}", nombre, usuario, email, password, nombre_taller, direccion_taller, venta_producto, telefono_taller);

                return View("AgregarM");
            }
            catch (Exception ex)
            {


                TempData["MSG"] = "No se agrego....: " + String.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7} - Error: {8}", nombre, usuario, email, password, nombre_taller, direccion_taller, venta_producto, telefono_taller, ex.Message);
                return View("AgregarM");
            }



        }








    }
}
