﻿using Microsoft.AspNetCore.Mvc;

namespace PaginaTallerMeca.Controllers
{
    public class Servicio : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
