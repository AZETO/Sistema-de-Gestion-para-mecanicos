﻿using Microsoft.AspNetCore.Mvc;

using MySql.EntityFrameworkCore;
using PaginaTallerMeca.Models;
using MySql.Data.MySqlClient;

namespace PaginaTallerMeca.Controllers
{
    public class RegistroController : Controller
    {
        public ActionResult Agregar()
        {

            return View();
        }

        public ActionResult AgregarPOST(string nombre, string usuario, string rut, string telefono, string direccion, string correo, string password )
        {
            try
            {
                string cadenaConexion = "server=localhost;database=db_sistema_mecanico;user=root;password=12345";

                MySqlConnection conexionDB = Conexion.Connexion();
                string sentencia = String.Format("INSERT INTO usuario_cliente (nombre, usuario, rut, telefono, direccion, correo, password) VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}' )", nombre, usuario, rut, telefono, direccion, correo, password);

                MySqlCommand com = new MySqlCommand(sentencia, conexionDB);

                conexionDB.Open();
                int cantidadFilasAfectadas = com.ExecuteNonQuery();
                conexionDB.Close();

                if (cantidadFilasAfectadas != 1)
                    throw new ApplicationException("No se agrego el usuario.");


                TempData["MSG"] = "Se agrego con exito: " + String.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}", nombre, usuario, rut, telefono, direccion, correo, password);

                return View("Agregar");
            }
            catch (Exception ex)
            {


                TempData["MSG"] = "No se agrego....: " + String.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6} - Error: {7}", nombre, usuario, rut, telefono, direccion, correo, password, ex.Message);
                return View("Agregar");
            }


            
        }
    }
}
