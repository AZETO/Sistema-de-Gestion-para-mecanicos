﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using PaginaTallerMeca.Models;

namespace PaginaTallerMeca.Controllers
{
    public class CatalogosController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ListaMeca()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ingresar(int cod, String nombre, String descrip, int precio)
        {
            String sql = "INSERT INTO usuario_mecanico (ID_mecanico, nombre, usuario, email, password, nombre_taller, direccion_taller, venta_producto, telefono_taller) VALUES ('" + cod + "', '" + nombre + "', '" + descrip + "', '" + precio + "')";

            MySqlConnection conexionDB = Conexion.Connexion();
            conexionDB.Open();
            try
            {
                MySqlCommand cmd = new(sql, conexionDB);
                cmd.ExecuteNonQuery();


            }
            catch (Exception exe)
            {
                Console.WriteLine("ERROR AL GUARDAR" + exe.Message);
            }
            finally
            {
                conexionDB.Close();
            }

            return RedirectToAction("ListaMeca", "Catalogo/ListaMeca");
        }







    }
}
